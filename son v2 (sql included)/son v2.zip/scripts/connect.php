<?php
$host = 'localhost';
$user = 'adminson';
$pass = 'AdM!n@N4Rs!nG';
$db = 'son';
$mysqli = new mysqli($host, $user, $pass,$db) or die($mysqli -> error);
?>